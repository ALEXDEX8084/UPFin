﻿using Converencia.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Converencia.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddJury.xaml
    /// </summary>
    public partial class AddJury : Page
    {
        private Jury _currentJury = new Jury();
        string imgLoc = "пусто";
        public AddJury(Jury selectedJury)
        {
            InitializeComponent();
            CMBPol.ItemsSource = ConferenceEntities.GetContext().Pol.ToList();
            CMBPol.SelectedValuePath = "IDPol";
            CMBPol.DisplayMemberPath = "NamePol";
            CMBCountry.ItemsSource = ConferenceEntities.GetContext().Country.ToList();
            CMBCountry.SelectedValuePath = "IDCountry";
            CMBCountry.DisplayMemberPath = "NameCountry";
            CMBDirection.ItemsSource = ConferenceEntities.GetContext().Direction.ToList();
            CMBDirection.SelectedValuePath = "IDDirection";
            CMBDirection.DisplayMemberPath = "NameDirection";

            if (selectedJury != null)
            {
                _currentJury = selectedJury;
            }
            DataContext = _currentJury;
        }
        private void BtnAddOrEdit_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentJury.FIO)) error.AppendLine("Укажите ФИО");
            if (string.IsNullOrWhiteSpace(_currentJury.Email)) error.AppendLine("Укажите логин");
            if (string.IsNullOrWhiteSpace(_currentJury.DateOfBirth.ToString())) error.AppendLine("Укажите дату рождения");
            if (string.IsNullOrWhiteSpace(_currentJury.Phone)) error.AppendLine("Укажите номер телефона");
            if (string.IsNullOrWhiteSpace(_currentJury.Pasword)) error.AppendLine("Укажите пароль");

            if (string.IsNullOrWhiteSpace(_currentJury.IDPol.ToString())) error.AppendLine("Укажите пол");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentJury.IDJury == 0)
            {
                ConferenceEntities.GetContext().Jury.Add(_currentJury);
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        string filename = imgLoc.Substring(imgLoc.LastIndexOf('\\') + 1);
                        _currentJury.Photo = String.Concat("/Photo/", filename);
                    }
                    if (imgLoc == "пусто") _currentJury.Photo = null;

                    ConferenceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new JuryList());
                    MessageBox.Show("Новый жюри успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        _currentJury.Photo = imgLoc;
                    }
                    if (imgLoc == "пусто") _currentJury.Photo = null;

                    ConferenceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new JuryList());
                    MessageBox.Show("Жюри успешно изменен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new JuryList());
        }
        private void PhotoLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog
                {
                    Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*",
                    Title = "Выберите фото/изображение организатора"
                };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    imageJury.Source = new BitmapImage(new Uri(imgLoc));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
