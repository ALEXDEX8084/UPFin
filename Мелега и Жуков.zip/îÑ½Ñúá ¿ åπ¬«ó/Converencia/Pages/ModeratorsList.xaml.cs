﻿using Converencia.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Converencia.Pages
{
    /// <summary>
    /// Логика взаимодействия для ModeratorsList.xaml
    /// </summary>
    public partial class ModeratorsList : Page
    {
        public ModeratorsList()
        {
            InitializeComponent();
            foreach (var item in dtgModerators.Items)
                MessageBox.Show(item.ToString());

            dtgModerators.Items.Clear();
            dtgModerators.ItemsSource = ConferenceEntities.GetContext().Moderators.ToList();
        }
        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Menu());
        }
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtSearch.Text.Count() != 0)
                dtgModerators.ItemsSource = ClassFrame.db.Moderators.Where(x => x.FIO.Contains(txtSearch.Text.ToLower()) || x.Country.NameCountry.Contains(txtSearch.Text.ToLower()) || x.Email.Contains(txtSearch.Text.ToLower())).ToList();
            else dtgModerators.ItemsSource = ClassFrame.db.Moderators.ToList();
        }
        private void MenuDelet_Click(object sender, RoutedEventArgs e)
        {
            var usersForRemoving = dtgModerators.SelectedItems.Cast<Moderators>().ToList();
            if (MessageBox.Show($"Удалить {usersForRemoving.Count()} модератора?",
                "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)

                try
                {
                    ConferenceEntities.GetContext().Moderators.RemoveRange(usersForRemoving);
                    ConferenceEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    dtgModerators.ItemsSource = ConferenceEntities.GetContext().Moderators.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }

        }
        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddModerators(null));
        }
        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddModerators((Moderators)dtgModerators.SelectedItem));
        }

    }
}
