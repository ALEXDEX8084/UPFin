﻿using Converencia.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Converencia.Pages
{
    /// <summary>
    /// Логика взаимодействия для ActivitesList.xaml
    /// </summary>
    public partial class ActivitesList : Page
    {
        public ActivitesList()
        {
            InitializeComponent();
            foreach (var item in dtgActivites.Items)
                MessageBox.Show(item.ToString());

            dtgActivites.Items.Clear();
            dtgActivites.ItemsSource = ConferenceEntities.GetContext().Activities.ToList();
        }
        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Menu());
        }
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtSearch.Text.Count() != 0)
                dtgActivites.ItemsSource = ClassFrame.db.Activities.Where(x => x.Jury.FIO.Contains(txtSearch.Text.ToLower()) || x.Participants.FIO.Contains(txtSearch.Text.ToLower()) || x.Moderators.FIO.Contains(txtSearch.Text.ToLower())).ToList();
            else dtgActivites.ItemsSource = ClassFrame.db.Activities.ToList();
        }
        private void MenuDelet_Click(object sender, RoutedEventArgs e)
        {
            var usersForRemoving = dtgActivites.SelectedItems.Cast<Activities>().ToList();
            if (MessageBox.Show($"Удалить {usersForRemoving.Count()} Активность?",
                "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)

                try
                {
                    ConferenceEntities.GetContext().Activities.RemoveRange(usersForRemoving);
                    ConferenceEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    dtgActivites.ItemsSource = ConferenceEntities.GetContext().Activities.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }

        }
        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddActivites(null));
        }
        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddActivites((Activities)dtgActivites.SelectedItem));
        }
    }
}
